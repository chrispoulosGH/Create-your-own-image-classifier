import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
import time
from PIL import Image
import  random
import glob
import numpy as np
import json
import argparse

def get_cat_to_name(file):
   with open(file, 'r') as f:
      cat_to_name = json.load(f)
   return cat_to_name

def load_checkpoint(load_dir):
    load_path=str(load_dir)+'/checkpoint.pth'
    state_dict = torch.load(load_path)
    #print(state_dict.keys())
    #model.load_state_dict(state_dict)
    model=torch.load(load_path)
    #print(model.idx_to_class)
    return model

def process_image(image_path):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    #print(image_path)
    image=Image.open(image_path)
    #define the transform
    image_transforms = transforms.Compose([transforms.Resize(224),
                                 transforms.CenterCrop(224),
                                 transforms.ToTensor(),
                                 transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])

    tensor_image=image_transforms(image)
    return tensor_image

def predict(device,image_path,  topk):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    processed_image=process_image(image_path)
    if device=='gpu':
        device='cuda'
    #state_dict = torch.load(ckp_path)
    #model.load_state_dict(state_dict)
    model.to(device)
    processed_image = processed_image.to(device)
    #print(image_path)
    #img = process_image(image_path)

    # TODO: Implement the code to predict the class from an image file
    with torch.no_grad():
       model.eval()
       processed_image=processed_image.unsqueeze(0)
       output = model.forward(processed_image)
    probabilities=torch.exp(output)
    probabilities.to(device)
    probs, indices=probabilities.topk(topk,dim=1)
    class_to_idx = model.class_to_idx
    if device == 'cpu':
        probs = probs.numpy()
        indices = indices.numpy()
    else:
        probs = probs.cpu().numpy()
        indices = indices.cpu().numpy()
    classes_indexed = {class_to_idx[i]: i for i in class_to_idx}
    classes_list =  list()
    for idx in indices[0]:
        classes_list.append(classes_indexed[idx])
    #print(class_to_idx)
    return probs, classes_list

parser = argparse.ArgumentParser(description='Classify a flower')
parser.add_argument('--load', help='checkpoint directory',dest='load_dir',action='store',required=False,type=str,default='.')
parser.add_argument('--image_path', help='image directory',dest='image_path',action='store',required=False,type=str,default='.')
parser.add_argument('--run_mode', help='gpu or cpu',dest='run_mode',action='store',required=False,default='cpu',nargs='?')
parser.add_argument('--topk', help='top probabilites of predicted images:',dest='topk',action='store',required=False,default='3',nargs='?',type=int)
parser.add_argument('--category_names', help='List of  categories to names',dest='category_names',action='store',required=False,default='cat_to_name.json',nargs='?',type=str)
args = parser.parse_args()
#print(args)
model=load_checkpoint(args.load_dir)
probs, classes_list=predict(args.run_mode,args.image_path, args.topk)
#print(model.class_to_idx)
#print(probs,classes_list)
cat2name=get_cat_to_name(args.category_names)
for i in range(args.topk):
   print("Flower is {} with a {:.1f} perent probability".format(cat2name[classes_list[i]],probs[0][i]*100))
