import matplotlib.pyplot as plt

import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
import time
from PIL import Image
import  random
import glob
import numpy as np
import json
import argparse


def train_data(data_dir):
    print(data_dir)
    #data_dir = 'flowers'
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
    data_transforms = transforms.Compose([transforms.Resize(224),
                                     transforms.CenterCrop(224),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])



    # TODO: Load the datasets with ImageFolder
    train_image_datasets = datasets.ImageFolder(data_dir + '/train', transform=data_transforms)
    test_image_datasets = datasets.ImageFolder(data_dir + '/test', transform=data_transforms)
    valid_image_datasets = datasets.ImageFolder(data_dir + '/valid', transform=data_transforms)
    # TODO: Using the image datasets and the trainforms, define the dataloaders
    train_dataloaders =  torch.utils.data.DataLoader(train_image_datasets, batch_size=64, shuffle=True)
    test_dataloaders =  torch.utils.data.DataLoader(test_image_datasets, batch_size=64, shuffle=True)
    valid_dataloaders =  torch.utils.data.DataLoader(valid_image_datasets, batch_size=64, shuffle=True)
    return train_dataloaders, test_dataloaders, train_image_datasets

def get_cat_to_name():
    with open('cat_to_name.json', 'r') as f:
        cat_to_name = json.load(f)

def set_model(model_type='vgg11'):
   if model_type=='vgg11':
      model = models.vgg11(pretrained=True)
   else:
      model=models.alexnet(pretrained=True)
   print(model)
   return model

def set_classifer(hidden_layer=1024,input_units=25088):
    for param in model.parameters():
        param.requires_grad = False

    from collections import OrderedDict
    classifier = nn.Sequential(OrderedDict([
                              ('fc1', nn.Linear(input_units, 4096)),
                              ('relu', nn.ReLU()),
                              ('drop', nn.Dropout(p=.5)),
                              ('fc2', nn.Linear(4096, hidden_layer)),
                              ('relu', nn.ReLU()),
                              ('drop2', nn.Dropout(p=.5)),
                              ('fc3', nn.Linear(hidden_layer, 102)),
                              ('relu', nn.ReLU()),
                              ('drop2', nn.Dropout(p=.5)),
                              ('output', nn.LogSoftmax(dim=1))
                              ]))

    model.classifier = classifier
    print(model)

def validation(model, testloader, criterion, device):
    test_loss = 0
    accuracy = 0
    for images, labels in testloader:
        images,labels=images.to(device),labels.to(device)
        #images.resize_(images.shape[0], 784)

        output = model.forward(images)
        test_loss += criterion(output, labels).item()

        ps = torch.exp(output)
        equality = (labels.data == ps.max(dim=1)[1])
        accuracy += equality.type(torch.FloatTensor).mean()

    return test_loss, accuracy

def train_model(train_dataloaders,test_dataloaders,learning_rate=.001,epochs=1,device='cpu'):
    if device!='cpu':
       device='cuda'

    model.train()
    for e in range(epochs):
        steps=0
        print_every = 10
        criterion = nn.NLLLoss()
        # Only train the classifier parameters, feature parameters are frozen
        optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)

        model.to(device)
        #train_dataloaders
        running_loss=0
        for ii, (inputs, labels) in enumerate(train_dataloaders):

            steps += 1
            #inputs.resize_(inputs.size()[0], 50176)
            # Move input and label tensors to the GPU
            inputs, labels = inputs.to(device), labels.to(device)

            start = time.time()
            optimizer.zero_grad()
            outputs = model.forward(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            if steps % print_every == 0:
                 model.eval()
                 with torch.no_grad():
                        model.to(device)
                        test_loss, accuracy = validation(model, test_dataloaders, criterion, device)
                 print("Epoch: {}/{}.. ".format(e+1, epochs),
                      "Training Loss: {:.3f}.. ".format(running_loss/print_every),
                      "Test Loss: {:.3f}.. ".format(test_loss/len(test_dataloaders)),
                      "Test Accuracy: {:.3f}".format(accuracy/len(test_dataloaders)))
                 running_loss=0
                 model.train()
    print(f"Device = {device}; Time per batch: {(time.time() - start)/3:.3f} seconds")

def save_checkpoint(architecture,train_image_datasets,save_dir='.'):
    save_path=str(save_dir)+'/checkpoint.pth'
    model.class_to_idx = train_image_datasets.class_to_idx
    #model.architecture=architecture
    #torch.save(model.state_dict(), save_path)
    torch.save(model, save_path)

def load_checkpoint(save_dir):
    save_path=str(save_dir)+'/checkpoint.pth'
    state_dict = torch.load(save_dir)
    #print(state_dict.keys())
    model.load_state_dict(state_dict)


parser = argparse.ArgumentParser(description='Train a Neural Network')
parser.add_argument('--data_directory', help='source directory',dest='data_directory',action='store',required=False,default='flowers',nargs='?',type=str)
parser.add_argument('--save', help='save model directory',dest='save_dir',action='store',required=False,type=str,default='.')
parser.add_argument('--arch', help='network architecture vgg11 or Alexnet',dest='architecture',action='store',required=False,default='vgg11',nargs='?')
parser.add_argument('--learning_rate', help='learning rate',dest='learning_rate',action='store',required=False,default=.001, type=float,nargs='?')
parser.add_argument('--hidden_units', help='number of hidden units',dest='hidden_units',action='store',required=False,default=1054, type=int,nargs='?')
parser.add_argument('--epochs', help='number of epochs',dest='epochs',action='store',required=False,default=1,type=int,nargs='?')
parser.add_argument('--run_mode', help='gpu or cpu:',dest='run_mode',action='store',choices=['gpu', 'cpu'],required=False,default='cpu',nargs='?')
args = parser.parse_args()

print(args)


train_dataloader,test_dataloader,train_image_dataset=train_data(args.data_directory)
model=set_model(args.architecture)
if args.architecture=='vgg11':
      input_units=25088
else: #AlexNet
      input_units=9216
set_classifer(args.hidden_units,input_units)
train_model(train_dataloader,test_dataloader,args.learning_rate,args.epochs,args.run_mode)
save_checkpoint(args.architecture,train_image_dataset,args.save_dir)
